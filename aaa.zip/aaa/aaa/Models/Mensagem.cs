﻿namespace aaa.Models
{
    public class Mensagem
    {
        public string Conteudo { get; set; }
    }
}

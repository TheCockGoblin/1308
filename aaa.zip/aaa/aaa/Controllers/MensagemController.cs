﻿using Microsoft.AspNetCore.Mvc;
using aaa.Models;
namespace aaa.Controllers
{
    public class MensagemController : Controller
    {
        public IActionResult Index(Mensagem mensagem)
        {
            ViewBag.Mensagem = mensagem.Conteudo;
            return View();
        }
    }
}